#!/bin/bash

cd `dirname $0`

if [ $# -lt 1 ]; then
	echo "Please provide input folder path"
	exit -1
fi
#INPUT_FOLDER=$1

LIB_JARS=`
for f in ./lib/*; do
        if [ -f $f ]; then
                echo -n "$f,"
        fi
done`
LIB_JARS=`ls hbase-conf/* | tr '\n' ','`$LIB_JARS,ada_config.properties
JAR="lib/ada-gdb-1.0.0-SNAPSHOT.jar"
MAIN_CLASS="ict.ada.gdb.dataloader.mapred.JsonFileProcessJob"
echo "[Hadoop lib jars] $LIB_JARS"

#-D mapred.min.split.size=536870912 #For very large input
#-D mapred.job.map.memory.mb=18000  #For memory-intensive jobs

export HADOOP_CLASSPATH=`ls lib/* | tr '\n' ':'`.
# 32M splits
#-D mapred.max.split.size=33554432  
#CMD="hadoop jar $JAR $MAIN_CLASS -libjars $LIB_JARS $@"
#mapred.min.split.size=2643931742
# 8M splits
CMD="hadoop jar $JAR $MAIN_CLASS -libjars $LIB_JARS -D mapred.min.split.size=33554432  $@"

#echo "[Command] $CMD"

# log=`date +%s`$RANDOM.log
if [[ ! -d .log ]]; then
  mkdir .log
fi

log=.log/`uuidgen`
$CMD 2>&1 | tee $log
grep "Success JSON Lines" $log >/dev/null
status=$?
rm $log
exit $status
