#!/bin/bash

#if [ $# -ne 1 ] || [ ! -f $1 ]; then
#	echo "Please provide input file path"
#	exit -1
#fi
#INPUT_FOLDER=$1
LIB_JARS=`
for f in ./lib/*; do
	if [ -f $f ]; then 
		echo -n "$f:" 
	fi
done`
#Hadoop classpath
HADOOP_HOME="/usr/local/hadoop"
HADOOP_CLASSPATH="$HADOOP_HOME/*"

#HBase classpath
HBASE_HOME="/usr/local/hbase"
HBASE_CLASSPATH="$HBASE_HOME/*:$HBASE_HOME/conf/:$HBASE_HOME/lib/*"

JAR="ada-gdb-0.0.2-SNAPSHOT.jar"
MAIN_CLASS="ict.ada.gdb.dataloader.LocalJsonFileLoader"

CLASSPATH="$HBASE_CLASSPATH:$LIB_JARS:$JAR:$HADOOP_CLASSPATH"

#GC_OPTS=" -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -Xloggc:./gc.log -verbose:gc -XX:+PrintHeapAtGC -XX:+PrintGCApplicationConcurrentTime -XX:+PrintGCApplicationStoppedTime "

CMD="java -cp $CLASSPATH -Xmx2g -Xms2g -Xmn512m -XX:+UseParallelGC -XX:+UseParallelOldGC -server $MAIN_CLASS $@"
# remote debug mode
#CMD="java -Xdebug -Xrunjdwp:transport=dt_socket,server=y,address=8765 -cp $CLASSPATH -Xmx4g -Xms4g -Xmn1g -XX:+UseParallelGC -XX:+UseParallelOldGC -server $MAIN_CLASS $@"
echo $CMD

$CMD 2>&1 | tee local.log
