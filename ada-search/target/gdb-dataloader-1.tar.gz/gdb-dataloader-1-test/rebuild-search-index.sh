#!/bin/bash

#if [ $# -ne 1 ] || [ ! -f $1 ]; then
#	echo "Please provide input file path"
#	exit -1
#fi

LIB_JARS=`
for f in ./lib/*; do
	if [ -f $f ]; then 
		echo -n "$f:" 
	fi
done`
# LIB_JARS=`ls hbase-conf/* | tr '\n' ':'`$LIB_JARS
LIB_JARS="hbase-conf:"$LIB_JARS
#Hadoop classpath
HADOOP_HOME="/usr/local/hadoop"
HADOOP_CLASSPATH="$HADOOP_HOME/*"

#HBase classpath
HBASE_HOME="/usr/local/hbase"
HBASE_CLASSPATH="$HBASE_HOME/*:$HBASE_HOME/conf/:$HBASE_HOME/lib/*"

JAR="ada-gdb-1.0.0-SNAPSHOT.jar"
MAIN_CLASS="ict.ada.gdb.toolkit.RebuildIndex"

CLASSPATH="$HBASE_CLASSPATH:$LIB_JARS:$JAR:$HADOOP_CLASSPATH"

#GC_OPTS=" -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -Xloggc:./gc.log -verbose:gc -XX:+PrintHeapAtGC -XX:+PrintGCApplicationConcurrentTime -XX:+PrintGCApplicationStoppedTime "

CMD="java -cp $CLASSPATH  -XX:+UseParallelGC -XX:+UseParallelOldGC -server $MAIN_CLASS $@"
# remote debug mode
#CMD="java -Xdebug -Xrunjdwp:transport=dt_socket,server=y,address=8765 -cp $CLASSPATH -Xmx4g -Xms4g -Xmn1g -XX:+UseParallelGC -XX:+UseParallelOldGC -server $MAIN_CLASS $1"
#echo $CMD

$CMD 2>&1 | tee delete-search-data.log
